<?php

defined('MOODLE_INTERNAL') || die;

$plugin->version  = 2022071400;   // The (date) version of this plugin
$plugin->requires = 2011021900;   // Requires this Moodle version
$plugin->component = 'local_edlink';