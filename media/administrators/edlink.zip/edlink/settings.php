<?php
if ($hassiteconfig) {
	//$ADMIN->add('root', new admin_category('local_edlink', get_string('pluginname','local_edlink')));
	$ADMIN->add('server', new admin_externalpage('local_edlink_settings', get_string('settings','local_edlink'), $CFG->wwwroot . '/local/edlink/index.php', array('local/edlink:manageclients')));
}
