<?php

require_once __DIR__.'/request.php';

$context = context_system::instance();

//Pagination parameters.
$page = optional_param('page', 0, PARAM_INT);
$limit = optional_param('limit', 100, PARAM_INT);

//Retrieve the requested users.
$sections = $DB->get_records(
    'course_sections',
    null,
    'id ASC',
    'id,course,section,name,summary,visible,availability,timemodified',
    $page * $limit,
    $limit
);

$response->setParameter('data', $sections);
$response->send();