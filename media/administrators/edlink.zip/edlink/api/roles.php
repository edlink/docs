<?php

require_once __DIR__.'/request.php';

$context = context_system::instance();

//Retrieve the requested users.
$users = $DB->get_records(
    'role',
    null,
    'id ASC',
    'id,name,shortname,description,archetype'
);

$response->setParameter('data', $users);
$response->send();