<?php

require_once __DIR__.'/request.php';
require_once '../../../course/externallib.php';

$response->setParameter('data', 2021012200);
$response->send();