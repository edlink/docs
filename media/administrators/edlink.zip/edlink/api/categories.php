<?php

require_once __DIR__.'/request.php';

$context = context_system::instance();

//Pagination parameters.
$page = optional_param('page', 0, PARAM_INT);
$limit = optional_param('limit', 100, PARAM_INT);

//Retrieve the requested users.
$users = $DB->get_records(
    'course_categories',
    null,
    'id ASC',
    'id,name,idnumber,description,parent,visible,timemodified,theme',
    $page * $limit,
    $limit
);

$response->setParameter('data', $users);
$response->send();