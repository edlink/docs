<?php

require_once __DIR__.'/request.php';

$context = context_system::instance();

$pluginman = core_plugin_manager::instance();
$response->setParameter('data', $pluginman->get_plugins());
$response->send();