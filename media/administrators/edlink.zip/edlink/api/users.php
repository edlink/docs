<?php

require_once __DIR__.'/request.php';
require_once '../../../course/externallib.php';

$context = context_system::instance();

//Pagination parameters.
$page = optional_param('page', 0, PARAM_INT);
$limit = optional_param('limit', 100, PARAM_INT);

//Retrieve the requested users.
$users = $DB->get_records(
    'user',
    null,
    'id ASC',
    'id,auth,deleted,suspended,username,idnumber,firstname,middlename,lastname,email,phone1,institution,department,address,city,country,lang,timezone,picture',
    $page * $limit,
    $limit
);

$response->setParameter('data', $users);
$response->send();