<?php

require_once __DIR__.'/request.php';

require_once('../../../config.php');
require_once($CFG->dirroot . '/course/modlib.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->libdir . '/filelib.php');
require_once($CFG->libdir . '/gradelib.php');
require_once($CFG->libdir . '/completionlib.php');
require_once($CFG->libdir . '/plagiarismlib.php');
require_once($CFG->dirroot . '/course/modlib.php');

//Pagination parameters.
$page = optional_param('page', 0, PARAM_INT);
$limit = optional_param('limit', 100, PARAM_INT);

//Form or query parameters.
$section = required_param('section', PARAM_INT);
$course = required_param('course', PARAM_INT);
$add = optional_param('add', '', PARAM_ALPHA);
$update = optional_param('update', 0, PARAM_INT);
$type = optional_param('type', '', PARAM_ALPHANUM);

$USER->ignoresesskey = true;

if (!empty($add)) {
    $course = $DB->get_record('course', array('id' => $course), '*', MUST_EXIST);

    require_login($course);

    //Create a new content module.
    list($module, $context, $cw, $cm, $data) = prepare_new_moduleinfo_data($course, $add, $section);

    $data->return = 0;
    $data->add = $add;

    if (!empty($type)) {
        $data->type = $type;
    }
} else if (!empty($update)) {
    // Check the course module exists.
    $cm = get_coursemodule_from_id('', $update, 0, false, MUST_EXIST);

    // Check the course exists.
    $course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);

    // require_login
    require_login($course, false, $cm); // needed to setup proper $COURSE

    // Ensure they can create this module.
    $modcontext = context_module::instance($cm->id);
    require_capability('moodle/course:manageactivities', $modcontext);

    list($cm, $context, $module, $data, $cw) = get_moduleinfo_data($cm, $course);
    $data->return = $return;
    $data->sr = $sectionreturn;
    $data->update = $update;
}

$modmoodleform = "$CFG->dirroot/mod/$module->name/mod_form.php";

if (file_exists($modmoodleform)) {
    require_once($modmoodleform);
} else {
    $response->setStatusCode(404);
    $response->setParameter('data', 'Moodle form not found.');
    $response->send();
    die();
}

$mformclassname = 'mod_' . $module->name . '_mod_form';
$mform = new $mformclassname($data, $cw->section, $cm, $course);
$mform->set_data($data);

if ($fromform = $mform->get_data()) {
    if (!empty($fromform->update)) {
        list($cm, $fromform) = update_moduleinfo($cm, $fromform, $course, $mform);
    } else if (!empty($fromform->add)) {
        $fromform = add_moduleinfo($fromform, $course, $mform);
    } else {
        //Bad request. Invalid form data.
        $response->setStatusCode(400);
        $response->setParameter('data', 'Invalid form data.');
        $response->send();
        die();
    }

    $response->setParameter('data', $fromform);
    $response->send();
}else{
    $response->setStatusCode(404);
    $response->setParameter('data', 'No data from form.');
    $response->send();
    die();
}