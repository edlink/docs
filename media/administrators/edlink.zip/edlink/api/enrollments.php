<?php

require_once __DIR__.'/request.php';

$context = context_system::instance();

//Pagination parameters.
$page = optional_param('page', 0, PARAM_INT);
$limit = optional_param('limit', 100, PARAM_INT);

//Retrieve the requested users.
$sql = "SELECT
        	ra.id AS enrollment_id,
        	u.id AS user_id,
        	c.id AS course_id,
        	r.id AS role_id,
        	ra.timemodified,
            r.shortname AS role_shortname,
            r.archetype AS role_archetype
        FROM {user} u
        INNER JOIN {role_assignments} ra ON ra.userid = u.id
        INNER JOIN {context} ct ON ct.id = ra.contextid
        INNER JOIN {course} c ON c.id = ct.instanceid
        INNER JOIN {role} r ON r.id = ra.roleid
        ORDER BY enrollment_id ASC";

$enrollments = $DB->get_records_sql($sql, null, $limit * $page, $limit);

$response->setParameter('data', $enrollments);
$response->send();